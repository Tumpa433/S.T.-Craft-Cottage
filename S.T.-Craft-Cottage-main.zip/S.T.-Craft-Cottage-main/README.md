# S.T. Craft Cottage

This is a React + Vite storefront. Product listings, filters, variant and colour selection, the basket, WhatsApp checkout, contact form, and the original responsive styles are retained.

## Run locally

1. Install Node.js (version 20.19+ or 22.12+).
2. Run `npm install`.
3. Run `npm run dev` and open the local URL printed by Vite.

## Build for XAMPP or other static hosting

Run `npm run build`, then copy the contents of the generated `dist` folder into the web root (or a subfolder) served by Apache. Keep all four generated HTML pages and the `assets` folder together. The existing `index.html`, `products.html`, `cart.html`, and `contact.html` URLs are retained.

The basket continues to use the browser storage key `stCraftCottageCart`.
